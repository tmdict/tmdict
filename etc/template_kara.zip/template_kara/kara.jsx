var intro = {
    "en": "<p><a href=\"http://tmdict.com/\">TMdict</a> is a multi-lingual dictionary of vocabularies from games, books, anime, and other works by Type-Moon. It is intended to be a light-weight, simple solution with basic sorting and searching functionality. Currently contents are available in the following languages: English, Chinese, and Japanese. We're always looking for more!</p><p>TMdict does not aim to be a comprehensive encyclopedia or a wiki, and does not carry any articles, analysis, or other editorials. Only text found in official materials and books and their translations can be found here.</p><p>TMdict Kara is created with HTML, CSS, and JavaScript, and React. It experiments with a clean, minimalistic design where all terms appear on one single page. Thanks to its minimal layout, it is also more printer-friendly.</p>",
    "zh": "<p><a href=\"http://tmdict.com/\">型月辞典</a>是一个以Type-Moon游戏，书，动漫等作品的词条为基础的多语言辞典。网站的目标以构造简约，注重内容质量，方便快捷的模式为重点，并提供一些简单的分类和搜索功能。目前我们支持英文，中文和日文。</p><p>型月辞典不是一个百科全书，也不是一个wiki，其内主要目的为Type-Moon官方用语和信息的翻译。没有出现在Type-Moon官方的设定或资料里的用语，不会出现在这里。</p><p>型月辞典Kara由HTML，CSS，和JavaScript做成。这是一个页面干净，设计简约，并把所有的内容都显示在一个页面上的实验。因为格式简单，它也很适合打印。</p>",
    "ja": "<p><a href=\"http://tmdict.com/\">TM辞典</a>は、ゲーム、書籍、アニメなどType-Moon の作品のボキャブラリーを収録した多言語辞書です。簡単な検索や並べ替え機能を備えた軽量かつシンプルなソリューションで、現在、英語、中国語、日本語でのコンテンツ利用が可能ですが、今後ますます内容を充実させていく予定です。</p><p>TMdictはエンサイクロペディアやWikiのような総合的な情報サイトとなることを目的としていません。そのため、記事や分析、コラムを除く、公式の作品や書籍からのテキストとその翻訳のみを掲載しています。</p><p>TMdict Kara は HTML、CSS、JavaScript、そしてReactで作成されています 。スッキリとミニマルなページ作りで、全ての用語を一つのページに収めてみました。シンプルなレイアウトで印刷用にも便利です。</p>"
};

var text = {
    "en": { "title": "TMdict", "link": "Link", "back": "Return", "note": "Translator's Notes" },
    "zh": { "title": "型月辞典", "link": "链接", "back": "返回", "note": "译者注" },
    "ja": { "title": "TM辞典", "link": "リンク", "back": "リターン", "note": "翻訳者注" }
};

function debug(string) {
    console.log(string);
}

var App = React.createClass({
    getInitialState: function () {
        return {
            lang: "en"
        };
    },
    handleLangSelect: function(lang) {
        this.setState({lang: lang});
    },
    componentDidMount : function() {
        $('#menu').hide();
        $('#menu ul li ul, #menu:hover ul li ul').hide();
        $(window).on('scroll', function() {
            if ($(window).scrollTop() > 400) { $('#menu').fadeIn('slow'); }
            else { $('#menu').fadeOut(); }
        });

        $('.expand').hover(function() { $('#menu ul li ul').fadeIn('slow'); },
                           function() { $('#menu ul li ul').hide(); });
    },
    render: function () {
        var indexArr = { "val": "", "str": "" };
        var indexNav;

        switch (this.state.lang) {
            case "en":
            case "zh":
                indexNav = "en";
                indexArr.str = _.chain(this.props.dict.data).pluck("index").pluck("en").uniq().sortBy().value();
                indexArr.val = _.map(indexArr.str.slice(), function(str) { if (str === "_") return "#"; else return str; });
                break;
            case "ja":
                indexNav = "ja";
                indexArr.str = _.chain(this.props.dict.data).pluck("index").pluck("ja").uniq().sortBy().value();
                indexArr.val = _.chain(this.props.dict.data).pluck("index").pluck("row").uniq().sortBy().value();
                break;
            default:
                indexNav = "";
                indexArr.str = "";
                indexArr.val = "";
        }

        var filterlist = _.chain(this.props.dict.data)
                            .groupBy(function (data) { return data.index[indexNav]; })
                            .map(function (data) {
                                return {
                                    "index": indexArr.val[_.indexOf(indexArr.str, data[0].index[indexNav])],
                                    "entries": _.sortBy(data, function (item) { return item[this.state.lang].title; }, this)
                                };
                            }, this)
                            .sortBy(function (data) { return data.index; })
                            .value();

        return (
            <div id="container">
                <Top lang={this.state.lang} version={this.props.dict.version} onLangSelect={this.handleLangSelect} />
                <Main lang={this.state.lang} index={indexArr} data={filterlist} />
                <Menu lang={this.state.lang} index={indexArr} data={this.props.dict.data} onLangSelect={this.handleLangSelect} />
            </div>
        );
    }
});

var Top = React.createClass({
    handleClick: function(lang) {
        this.props.onLangSelect(lang);
    },
    render: function () {
        return (
            <div id="top">
                <div className="wrapper group">
                    <h1><span className="tm">{text[this.props.lang].title.slice(0, 2)}</span>{text[this.props.lang].title.slice(2, text[this.props.lang].title.length)}</h1>
                    <div className="ver">{this.props.version}</div>
                    <div className="lang">
                        <a href="#" className={(this.props.lang === "en")? "active" : ""} href={"#" + this.props.lang} onClick={this.handleClick.bind(this, "en")}>English</a> | 
                        <a href="#" className={(this.props.lang === "zh")? "active" : ""} href={"#" + this.props.lang} onClick={this.handleClick.bind(this, "zh")}>中文</a> | 
                        <a href="#" className={(this.props.lang === "ja")? "active" : ""} href={"#" + this.props.lang} onClick={this.handleClick.bind(this, "ja")}>日本語</a> | 
                        <a href={"http://tmdict.com/" + this.props.lang + "/"}>⤵</a>
                    </div>
                </div>
            </div>
        );
    }
});

var Main = React.createClass({
    render: function () {
        return (
            <div className="wrapper">
                <div id="main">
                    <div id="intro" dangerouslySetInnerHTML={{__html: intro[this.props.lang]}} />

                    {this.props.data.map(function (list, i) {
                        return (
                            <div key={i}>
                                <h2 key={i} id={this.props.lang + "." + this.props.index.str[i]}>{this.props.index.val[i]}</h2>

                                {list.entries.map(function (entry, j) {
                                    return <Entry key={j} lang={this.props.lang} index={this.props.index.str[i]} entry={entry} />
                                }, this)}
                            </div>
                        );
                    }, this)}
                </div>
            </div>
        );
    }
});

var Entry = React.createClass({
    render: function () {
        var entrylink = this.props.lang + "." + this.props.index + "." + this.props.entry.entry;
        return (
            <div className="entry" id={entrylink}>
                <div className="entry-header group">
                    <div className="entry-title">{this.props.entry[this.props.lang].title}</div>
                    <div className="permalink"><a href={"#" + entrylink} title={text[this.props.lang].link}>#</a></div>
                </div>

                {this.props.entry[this.props.lang].source.map(function (d, i) {
                    var content = this.props.entry[this.props.lang].content[i].replace(/#note/g, ("#" + entrylink + ".note"));
                    content = content.replace(/sup id=\"/g, ("sup id=\"" + entrylink + "."));
                    return <div key={i} className="group">
                        {(i > 0) ? <div className="section">&sect;</div> : ""}
                        <div className="entry-category">{this.props.entry[this.props.lang].category[i].map(function (item, i) {
                            if (i > 0) {
                                item = " · " + item;
                            }
                            item = item.replace(/__/g, "");
                            item = item.replace(/_na/g, "-");
                            item = item.replace(/_qn/g, "?");
                            return item;
                        })}</div>
                        <div className="entry-content"><p dangerouslySetInnerHTML={{__html: content}} /></div>
                        <div className="entry-source">{this.props.entry[this.props.lang].source[i][0] + ": " + this.props.entry[this.props.lang].source[i][1]}</div>
                    </div>
                }, this)}

                {(this.props.entry.img.length === 0) ? "" : 
                    <div className="group">
                        <div className="section">&sect;</div>

                        <div className="entry-image">
                            {this.props.entry.img.map(function (d, i) {
                                return <img key={i} title={this.props.entry[this.props.lang].title} src={"/src/img/dict/" + d} alt={d} />
                            }, this)}
                        </div>
                    </div>
                }

                {(this.props.entry[this.props.lang].note.length === 0) ? "" : 
                    <div className="group">
                        <div className="entry-note">
                            <h3>{text[this.props.lang].note}</h3>
                            <ol>
                                {this.props.entry[this.props.lang].note.map(function (n, i) {
                                    return <li key={i} id={entrylink + ".note" + (i + 1)}><a href={"#" + entrylink + ".n" + (i + 1)}>^</a> {n}</li>
                                }, this)}
                            </ol>
                        </div>
                    </div>
                }
            </div>
        );
    }
});

var Menu = React.createClass({
    handleClick: function(lang) {
        this.props.onLangSelect(lang);
    },
    render: function () {
        return (
            <div id="menu">
                <ul>
                    <li className="expand"><a>+</a>
                    <ul>
                        {this.props.index.str.map(function (index, i) {
                            return (
                                <li key={i}><a href={"#" + this.props.lang + "." + index}>{this.props.index.val[i]}</a></li>
                            );
                        }, this)}
                    </ul></li>
                    <li><a className={(this.props.lang === "en")? "active" : ""} href={"#" + this.props.lang} onClick={this.handleClick.bind(this, "en")}>En</a></li>
                    <li><a className={(this.props.lang === "zh")? "active" : ""} href={"#" + this.props.lang} onClick={this.handleClick.bind(this, "zh")}>中</a></li>
                    <li><a className={(this.props.lang === "ja")? "active" : ""} href={"#" + this.props.lang} onClick={this.handleClick.bind(this, "ja")}>日</a></li>
                    <li><a href={"http://tmdict.com/" + this.props.lang + "/"}>⤵</a></li>
                </ul>
            </div>
        );
    }
});

React.render(
    <App dict={dict} />,
    document.body
);